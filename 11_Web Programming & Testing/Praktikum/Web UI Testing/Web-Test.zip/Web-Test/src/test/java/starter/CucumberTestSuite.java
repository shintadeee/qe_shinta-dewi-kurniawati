package starter;

public class CucumberTestSuite {
}
