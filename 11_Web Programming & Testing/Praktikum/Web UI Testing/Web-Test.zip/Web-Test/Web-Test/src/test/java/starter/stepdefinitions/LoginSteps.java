package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;
import starter.login.Product;

public class LoginSteps {
    @Steps
    Login login;

    @Steps
    Home home;

    @Steps
    Product product;


    @Given("I am on the login page")
    public void onTheLoginPage(){
        login.openUrl("https://www.saucedemo.com/");
        login.validateOnTheLoginPage();
    }

    @When("I enter valid username")
    public void enterValidUsername(){
        login.inputUsername("standard_user");
    }

    @And("I enter valid password")
    public void enterValidPassword(){
        login.inputPassword("secret_sauce");
    }

    @And("I click login button")
    public void clickLoginButton(){
        login.clickLoginButton();
    }

    @Then("I am on the home page")
    public void onTheHomePage(){
        home.validateOnTheHomePage();
    }

    @When("I enter invalid username")
    public void enterInvalidUsername(){
        login.inputUsername("locked_out_user");
    }

    @Then("I should see an error message")
    public void seeAnErrorMessage(){
        login.isErrorMessageDisplayed();
    }

    @When("I select a product")
    public void selectProduct(){
        product.selectProduct();
    }

    @And("I click Add to Cart button")
    public void clickAddToCartButton(String buttonText){
        product.clickAddToCartButton(buttonText);
    }

    @And("I click the cart icon")
    public void clickCartIcon(){
        product.clickCartButton();
    }

    @Then("I should see the added product in my cart page")
    public void seeTheAddedProductInMyCartPage(){
        product.validateOnTheCartPage();

    }
}
