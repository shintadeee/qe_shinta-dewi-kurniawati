package starter.login;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class Product extends PageObject {
    private By productField(){ return By.id("product");}
    private By addToCartButton(){
        return By.id("add-to-cart-button");
    }
    private By cartButton(){
        return By.id("cart-button");
    }

    @Step
    public void selectProduct(){
        $(productField()).isDisplayed();
    }

    @Step
    public void clickAddToCartButton(String buttonText){
        $(addToCartButton()).click();
    }

    @Step
    public void clickCartButton(){
        $(cartButton()).click();
    }

    @Step
    public void validateOnTheCartPage(){
        $(cartButton()).isDisplayed();
    }
}
