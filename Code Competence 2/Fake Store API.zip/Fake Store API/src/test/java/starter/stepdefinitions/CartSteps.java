package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.api.cart.DeleteCart;
import starter.api.cart.GetAllCarts;
import starter.api.cart.UpdateCart;

public class CartSteps {
    @Steps
    GetAllCarts getAllCarts;
    @Steps
    UpdateCart updateCart;
    @Steps
    DeleteCart deleteCart;


    @Given("I set a GET endpoints cart")
    public void setGetEndpointsCart(){getAllCarts.setGetEndpointsCart();}
    @When("I send HTTP GET request cart")
    public void getHttpRequestCart(){getAllCarts.getHttpRequestCart();}
    @Then("I receive a valid HTTP response code 200 OK for cart")
    public void HttpResponse200forCart(){getAllCarts.HttpResponse200forCart();}
    @And("I received valid data for all cart details")
    public void validDataCart(){getAllCarts.validDataCart();}

    @Given("I set PUT endpoints for cart")
    public void setPutEndpointCart(){
        updateCart.setPutEndpointCart();
    }
    @When("I send PUT HTTP request for cart")
    public void sendPutHttpRequestCart(){
        updateCart.sendPutHttpRequestCart();
    }
    @Then("I receive valid HTTP Put response code is 200 OK for cart")
    public void receiveResponseCode200OKPut(){ updateCart.receiveResponseCode200OKPut();}
    @And("I receive valid data for existing cart")
    public void ValidateDataForExistingCart(){
        updateCart.ValidateDataForExistingCart();
    }

    @Given("I set DELETE endpoints cart")
    public void setDeleteCartEndpoint(){deleteCart.setDeleteCartEndpoint();}
    @When("I send DELETE HTTP request cart")
    public void sendDeleteCartHttpRequest(){deleteCart.sendDeleteCartHttpRequest();}
    @Then("I receive valid DELETE HTTP response code 200 OK for cart")
    public void validCartHttpResponseCode200(){deleteCart.validCartHttpResponseCode200();}

}
