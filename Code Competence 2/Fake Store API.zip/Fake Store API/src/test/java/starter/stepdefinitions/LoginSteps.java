package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.api.login.Login;

public class LoginSteps {
    @Steps
    Login login;

    @Given("I set POST endpoints for Login")
    public void setPostLoginEndpoints(){login.setPostLoginEndpoints();}
    @When("I send POST HTTP request for login")
    public void sendPostRequest(){login.sendPostRequest();}
    @Then("I get valid HTTP response code 400 Bad Request after login")
    public void getResponseCode400(){login.getResponseCode400();}
    @And("I can't get token after login")
    public void validateLogin(){login.validateLogin();}

}
