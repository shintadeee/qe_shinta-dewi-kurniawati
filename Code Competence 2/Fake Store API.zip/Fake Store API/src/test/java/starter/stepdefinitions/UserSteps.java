package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.api.user.DeleteUser;
import starter.api.user.GetAllUsers;

public class UserSteps {
    @Steps
    GetAllUsers getAllUsers;
    @Steps
    DeleteUser deleteUser;


    @Given("I set a GET endpoints user")
    public void setGetEndpointsUser(){getAllUsers.setGetEndpointsUser();}
    @When("I send HTTP GET request user")
    public void getHttpRequestUser(){getAllUsers.getHttpRequestUser();}
    @Then("I receive a valid HTTP response code 200 OK for user")
    public void HttpResponse200forUser(){getAllUsers.HttpResponse200forUser();}
    @And("I received valid data for all user details")
    public void validDataUser(){getAllUsers.validDataUser();}

    @Given("I set DELETE endpoints user")
    public void setDeleteEndpointUser(){deleteUser.setDeleteEndpointUser();}
    @When("I send DELETE HTTP request user")
    public void sendDeleteHttpRequestUser(){deleteUser.sendDeleteHttpRequestUser();}
    @Then("I receive valid DELETE HTTP response code 200 OK for user")
    public void validHttpResponseCode200forUser(){deleteUser.validHttpResponseCode200forUser();}

}
