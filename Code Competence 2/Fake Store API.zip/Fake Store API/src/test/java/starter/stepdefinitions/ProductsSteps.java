package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.api.products.AddNewProduct;
import starter.api.products.DeleteProduct;
import starter.api.products.GetAllCategories;
import starter.api.products.GetAllProducts;

public class ProductsSteps {
    @Steps
    GetAllProducts getAllProducts;
    @Steps
    GetAllCategories getAllCategories;
    @Steps
    AddNewProduct addNewProduct;
    @Steps
    DeleteProduct deleteProduct;


    @Given("I set a GET endpoints")
    public void setGetEndpoints(){getAllProducts.setGetEndpoints();}
    @When("I send HTTP GET request")
    public void getHttpRequest(){getAllProducts.getHttpRequest();}
    @Then("I receive a valid HTTP response code 200 OK")
    public void HttpResponse200(){getAllProducts.HttpResponse200();}
    @And("I received valid data for all product details")
    public void validData(){getAllProducts.validData();}

    @Given("I set a GET product category endpoints")
    public void setGetAllCategoriesEndpoints(){getAllCategories.setGetCategoriesEndpoints();}
    @When("I send category HTTP GET request")
    public void categoriesGetHttpRequest(){getAllCategories.categoriesGetHTTPRequest();}
    @Then("I receive a valid category HTTP response code 200 OK")
    public void HttpCategoriesResponse200(){getAllCategories.HTTPCategoriesResponse200();}
    @And("I received valid data for all product category details")
    public void validCategoriesData(){getAllCategories.validCategoriesData();}

    @Given("I set POST endpoints")
    public void setPostApiEndpoint(){
        addNewProduct.setPostApiEndpoint();
    }
    @When("I send POST HTTP request")
    public void sendPostHTTPRequest(){
        addNewProduct.sendPostHttpRequest();
    }
    @Then("I receive valid HTTP response code 200 OK")
    public void receiveValidHttp201(){addNewProduct.receiveHttpResponseCode200();}
    @And("I receive valid data for new product")
    public void validateDataNewProduct(){
        addNewProduct.validateDatanewProduct();
    }

    @Given("I set DELETE endpoints")
    public void setDeleteEndpoint(){deleteProduct.setDeleteEndpoint();}
    @When("I send DELETE HTTP request")
    public void sendDeleteHttpRequest(){deleteProduct.sendDeleteHttpRequest();}
    @Then("I receive valid DELETE HTTP response code 200 OK")
    public void validHttpResponseCode200(){deleteProduct.validHttpResponseCode200();}

}
