package starter.api.cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class UpdateCart {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set PUT endpoints for cart")
    public String setPutEndpointCart(){
        return url + "carts/7";
    }

    @Step("I send PUT HTTP request for cart")
    public void sendPutHttpRequestCart(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("userId", 3);
        requestBody.put("date", "2019-12-10");

        JSONArray productsArray = new JSONArray();

        JSONObject product1 = new JSONObject();
        product1.put("productId", 1);
        product1.put("quantity", 3);
        productsArray.add(product1);

        requestBody.put("products", productsArray);

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutEndpointCart());
    }

    @Step("I receive valid HTTP Put response code is 200 OK for cart")
    public void receiveResponseCode200OKPut(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for existing cart")
    public void ValidateDataForExistingCart(){
        restAssuredThat(response -> response.body("userId", equalTo(3)));
        restAssuredThat(response -> response.body("date", equalTo("2019-12-10")));
        restAssuredThat(response -> response.body("products[0].productId", equalTo(1)));
        restAssuredThat(response -> response.body("products[0].quantity", equalTo(3)));
    }

}
