package starter.api.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteUser {
    protected String url = "https://fakestoreapi.com/";
    @Step("I set DELETE endpoints user")
    public String setDeleteEndpointUser(){
        return url + "users/6";
    }
    @Step("I send DELETE HTTP request user")
    public void sendDeleteHttpRequestUser(){
        SerenityRest.given().delete(setDeleteEndpointUser());
    }
    @Step("I receive valid DELETE HTTP response code 200 OK for user")
    public void validHttpResponseCode200forUser(){
        restAssuredThat(response -> response.statusCode(200));
    }

}
