package starter.api.cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteCart {
    protected String url = "https://fakestoreapi.com/";
    @Step("I set DELETE endpoints cart")
    public String setDeleteCartEndpoint(){
        return url + "carts/6";
    }
    @Step("I send DELETE HTTP request cart")
    public void sendDeleteCartHttpRequest(){
        SerenityRest.given().delete(setDeleteCartEndpoint());
    }
    @Step("I receive valid DELETE HTTP response code 200 OK for cart")
    public void validCartHttpResponseCode200(){
        restAssuredThat(response -> response.statusCode(200));
    }
}
