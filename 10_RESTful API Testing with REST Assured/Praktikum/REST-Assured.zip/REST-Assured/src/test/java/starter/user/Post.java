package starter.user;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class Post {

    protected String url = "https://jsonplaceholder.typicode.com/posts";

    @Step("I set POST endpoints")
    public String setPostEndpoint(){

        return url + "users";
    }

    @Step("I send POST HTTP request")
    public void sendPostHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", "test post");
        requestBody.put("body", "this is post data example");

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostEndpoint());
    }

    @Step("I receive valid HTTP response code 201")
    public void receiveHttpResponseCode201(){
        restAssuredThat(response -> response.statusCode(201));
    }

    @Step("I receive valid data for new post data")
    public void validateDataNewPostData(){
        restAssuredThat(response -> response.body("'title'", equalTo("test post")));
        restAssuredThat(response -> response.body("'body'", equalTo("this is post data example")));
    }
}
