package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;

public class Get {
    protected static String url = "https://jsonplaceholder.typicode.com/posts";

    @Step("I set GET endpoints")
    public String setGetEndpoint(){

        return url + "users/2";
    }

    @Step("I send GET HTTP request")
    public void sendGetHttpRequest(){
        SerenityRest.given()
                .when()
                .get(setGetEndpoint());
    }

    @Step("I receive valid HTTP response code 200")
    public void validateHttpResponseCode200(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive all valid post data")
    public void validateAllValidPostData(){
        restAssuredThat(response -> response.body("'data'.'userId'", equalTo(1)));
        restAssuredThat(response -> response.body("'data'.'id'", equalTo(1)));
    }
}
