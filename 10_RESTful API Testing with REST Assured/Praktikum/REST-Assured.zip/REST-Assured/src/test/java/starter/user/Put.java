package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class Put {

    protected String url = "https://jsonplaceholder.typicode.com/posts/1";

    @Step("I set PUT endpoints")
    public String setPutEndpoint(){

        return url + "users/2";
    }

    @Step("I send PUT HTTP request")
    public void sendPutHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", "test post");
        requestBody.put("body", "this is test post");

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutEndpoint());
    }

    @Step("I receive valid data for post data")
    public void ValidateDataForPostData(){
        restAssuredThat(response -> response.body("'title'", equalTo("test post")));
        restAssuredThat(response -> response.body("'body'", equalTo("this is test post")));
    }
}
