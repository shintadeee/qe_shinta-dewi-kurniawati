package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class HomepageSteps {

    //Scenario: Login
    @Given("I am on the login page")
    public void onTheLoginPage(){}
    @When("I enter a valid email and password")
    public void enterValidEmailAndPassword(){}

    @And("I clicks on the login button")
    public void clickOnLoginButton(){}

    @Then("I am redirected to the homepage")
    public void redirectedToTheHomepage(){}

    //Scenario: Search
    @Given("I have entered the LinkedIn homepage")
    public void enteredTheLinkedInHomepage(){}

    @When("I type search keywords in the search box")
    public void typeSearchKeywordsInTheSearchBox(){}

    @And("I click the Search button")
    public void clickTheSearchButton(){}

    @Then("I will look at the relevant search results")
    public void lookAtTheRelevantSearchResults(){}

    //Scenario: Profile Picture
    @When("I click on my or someone else's user profile")
    public void clickOnMyOrSomeoneElseUserProfile(){}

    @Then("I see complete user profile information")
    public void seeCompleteUserProfileInformation(){}

    //Scenario: Post Status
    @When("I click Start a Post button")
    public void clickStartPostButton(){}

    @And("I typed in my status and clicked the post button")
    public void typeInMyStatusAndClickedThePostButton(){}

    @Then("I see my post appear on my LinkedIn homepage")
    public void seeMyPostAppearOnMyLinkedInHomepage(){}

}
