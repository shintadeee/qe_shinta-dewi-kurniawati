package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
public class LoginSteps {

    //Scenario: Login
    @Given("I am on the Sepulsa homepage")
    public void onTheSepulsaHomepage(){}
    @When("I click on the login button")
    public void clickOnTheLoginButton(){}

    @And("I enter my username and password")
    public void enterMyUsernameAndPassword(){}

    @Then("I should be redirected to the dashboard page")
    public void redirectedToTheDashboardPage(){}

    //Scenario: Purchase a Product
    @Given("I am logged in Sepulsa")
    public void loggedInSepulsa(){}
    @When("I select a product")
    public void selectProduct(){}

    @And("I choose a payment method")
    public void choosePaymentMethod(){}

    @And("I click on the pay now button")
    public void clickOnThePayNowButton(){}

    @Then("I should see a confirmation message")
    public void seeConfirmationMessage(){}
}
